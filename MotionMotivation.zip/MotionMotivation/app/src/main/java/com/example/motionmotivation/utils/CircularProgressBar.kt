package com.example.motionmotivation.utils

import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.util.Log
import android.view.View
import kotlin.math.min
import kotlin.math.roundToInt


class CircularProgressBar(context: Context, attributeSet: AttributeSet) :
    View(context, attributeSet) {
    private var strokeWidth = 4f //thickness of progress bar
    private var progress = 0f
    private var min = 0
    private var max = 100
    private val startAngle = -90 //start progress at 12 o'clock
    private var color: Int = Color.DKGRAY
    private var rectF: RectF? = null
    private var backgroundPaint: Paint? = null
    private var foregroundPaint: Paint? = null
    private val hsv = floatArrayOf(220f, 89f, 100f)
    private fun init(context: Context, attributeSet: AttributeSet) {
        rectF = RectF()
        val typedArray: TypedArray = context.theme
            .obtainStyledAttributes(
                attributeSet,
                com.example.motionmotivation.R.styleable.CircleProgressBar,
                0,
                0
            )
        try {
            strokeWidth = typedArray.getDimension(
                com.example.motionmotivation.R.styleable.CircleProgressBar_progressBarThickness,
                strokeWidth
            )
            progress = typedArray.getFloat(com.example.motionmotivation.R.styleable.CircleProgressBar_progress, progress)
            min = typedArray.getInt(com.example.motionmotivation.R.styleable.CircleProgressBar_min, min)
            max = typedArray.getInt(com.example.motionmotivation.R.styleable.CircleProgressBar_max, max)
            color = typedArray.getInt(com.example.motionmotivation.R.styleable.CircleProgressBar_progressbarColor, color)
        } finally {
            typedArray.recycle()
        }
        backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        backgroundPaint!!.color = adjustAlpha(color, 0.3f)
        backgroundPaint!!.style = Paint.Style.STROKE
        backgroundPaint!!.strokeWidth = strokeWidth
        foregroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        foregroundPaint!!.color = adjustAlpha(color, 0.3f)
        foregroundPaint!!.style = Paint.Style.STROKE
        foregroundPaint!!.strokeWidth = strokeWidth
    }

    private fun adjustAlpha(color: Int, factor: Float): Int {
        val alpha = (Color.alpha(color) * factor).roundToInt()
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

     override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        Log.v("Chart onMeasure w", MeasureSpec.toString(widthMeasureSpec))
        Log.v("Chart onMeasure h", MeasureSpec.toString(heightMeasureSpec))
        val width = getDefaultSize(suggestedMinimumWidth, widthMeasureSpec)
        val height = getDefaultSize(suggestedMinimumHeight, heightMeasureSpec)
        val min = min(width, height)
        setMeasuredDimension(min, min)
        rectF!![0 + strokeWidth / 2, 0 + strokeWidth / 2, min - strokeWidth / 2] =
            min - strokeWidth / 2
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        rectF?.let { backgroundPaint?.let { it1 -> canvas.drawOval(it, it1) } }
        val angle = 360 * (progress / max)
        rectF?.let { foregroundPaint?.let { it1 ->
            canvas.drawArc(it, startAngle.toFloat(), angle, false,
                it1
            )
        } }
    }

    fun setProgress(progress: Int) {
        this.progress = progress.toFloat()
        invalidate()
    }

    fun setColor(progress: Int) {
        hsv[0] = (100.toFloat() - progress) * 2.2f
        color = Color.HSVToColor(hsv)
        foregroundPaint!!.color = color
        invalidate()
        requestLayout()
    }

    init {
        init(context, attributeSet)
    }
}