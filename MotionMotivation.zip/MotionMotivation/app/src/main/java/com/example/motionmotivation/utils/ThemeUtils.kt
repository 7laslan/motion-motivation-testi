package com.example.motionmotivation.utils

import android.R
import android.content.Context
import android.preference.PreferenceManager


object ThemeUtils {
    const val ThemeKey = "is_dark_theme"
    fun checkTheme(activityContext: Context) {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(activityContext)
        val isDarkTheme = sharedPreferences.getBoolean(ThemeKey, false)
        if (isDarkTheme) {
            activityContext.setTheme(R.style.Theme)
        } else {
            activityContext.setTheme(R.style.Theme)
        }
    }
}