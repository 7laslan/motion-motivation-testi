package com.example.motionmotivation.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.CountDownTimer


class SittingTimerUtils(
    var millisInFuture: Long,
    millisPassed: Long,
    countDownInterval: Long,
    val context: Context
) :
    CountDownTimer(
        millisInFuture - millisPassed,
        countDownInterval
    ) {
    var isRunning = false
        private set

    override fun onTick(millisUntilFinished: Long) {
        updateTimer(millisUntilFinished)
    }

    override fun onFinish() {
        updateTimer(millisInFuture)
        isRunning = false
        val finishedIntent = Intent()
        finishedIntent.action = MM_TIMER_ACTION_FINISHED
        context.sendBroadcast(finishedIntent, null)
    }

    @SuppressLint("DefaultLocale")
    fun updateTimer(millisUntilFinished: Long) {
        val progressInPercent =
            ((millisInFuture - millisUntilFinished) * 100 / millisInFuture).toInt()
        val currentTimeLeft = formatTimeText(millisUntilFinished.toInt(), progressInPercent, context)
        val updateIntent = Intent()
        updateIntent.setAction(MM_TIMER_ACTION_Time_CHANGED)
            .putExtra("progressInPercent", progressInPercent)
            .putExtra("currentTimeLeft", currentTimeLeft)
        context.sendOrderedBroadcast(updateIntent, null)
    }

    fun startTimer() {
        start()
        isRunning = true
    }

    fun resetTimer() {
        cancel()
        start()
        isRunning = true
    }

    fun stopTimer(nextMillisInFuture: Long) {
        cancel()
        millisInFuture = nextMillisInFuture
        updateTimer(nextMillisInFuture)
        isRunning = false
    }

    companion object {
        const val MM_TIMER_ACTION_Time_CHANGED = "com.example.app.motionmotivation.actiontimechanged"
        const val MM_TIMER_ACTION_FINISHED = "com.example.app.motionmotivation.actiontimerfinished"
        fun formatTimeText(
            millisUntilFinished: Int,
            progressInPercent: Int,
            context: Context
        ): String {
            val currentTimeLeft: String = if (progressInPercent == 100) {
                context.getString(com.example.motionmotivation.R.string.zero_time)
            } else {
                String.format(
                    "%02d:%02d",
                    millisUntilFinished / 60000, millisUntilFinished / 1000 % 60
                )
            }
            return currentTimeLeft
        }
    }

}