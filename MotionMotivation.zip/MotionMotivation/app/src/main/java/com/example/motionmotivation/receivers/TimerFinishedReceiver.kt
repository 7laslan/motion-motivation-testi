package com.example.motionmotivation.receivers

import android.R
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.preference.PreferenceManager
import com.example.motionmotivation.AlarmActivity
import com.example.motionmotivation.utils.NotificationUtils
import com.example.motionmotivation.utils.SittingTimerUtils.Companion.MM_TIMER_ACTION_FINISHED


class TimerFinishedReceiver : BroadcastReceiver() {
    var context: Context? = null
    override fun onReceive(context: Context?, intent: Intent) {
        if (intent.action != null) {
            if (intent.action == MM_TIMER_ACTION_FINISHED) {
                this.context = context
                val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
                val isAlarm = sharedPreferences.getBoolean("alarm", false)
                if (isAlarm) {
                    sendAlarm()
                } else {
                    sendNotification()
                }
            }
        }
    }

    private fun sendAlarm() {
        val intent = Intent(context, AlarmActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_TASK_ON_HOME or Intent.FLAG_ACTIVITY_NEW_TASK
        context?.startActivity(intent)
    }

    private fun sendNotification() {
        val contentText: String = context!!.getString(com.example.motionmotivation.R.string.sitting_time_finished)
        val breakActionText: String = context!!.getString(com.example.motionmotivation.R.string.take_break)
        val finishNotification: NotificationUtils =
            object : NotificationUtils(context!!, TIMER_FINISHED_NOTIFICATION_ID) {
                override fun setBuilder() {
                    builder.setContentText(contentText)
                        .addAction(com.example.motionmotivation.R.drawable.ic_arrov_back24, breakActionText, breakAction)
                }
            }
        finishNotification.showNotification()
    }
}
