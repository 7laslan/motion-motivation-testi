package com.example.motionmotivation.utils

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator


class AlarmUtils {
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    fun alarmUtils(context: Context) {
        mediaPlayer = MediaPlayer.create(
            context,
            com.example.motionmotivation.R.raw.sound1
        )
        mediaPlayer!!.isLooping = true
        vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator?
    }

    private fun vibrate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator!!.vibrate(
                VibrationEffect.createOneShot(
                    250,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
        } else {
            vibrator!!.vibrate(250)
        }
    }

    fun start() {
        mediaPlayer!!.start()
        vibrate()
    }

    fun stop() {
        mediaPlayer!!.stop()
        vibrator!!.cancel()
    }
}