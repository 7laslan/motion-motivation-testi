package com.example.motionmotivation.receivers

import android.R
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.motionmotivation.utils.NotificationUtils
import com.example.motionmotivation.utils.SittingTimerUtils.Companion.MM_TIMER_ACTION_Time_CHANGED


class TimerNotificationReceiver : BroadcastReceiver() {
    private var TimerNotification: NotificationUtils? = null
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != null) {
            if (intent.action == MM_TIMER_ACTION_Time_CHANGED) {
                val contentText: String = context.resources.getString(com.example.motionmotivation.R.string.time_remaining)
                    .toString() + intent.getStringExtra("currentTimeleft")
                val actionTitle: String = context.getString(com.example.motionmotivation.R.string.reset)
                if (TimerNotification == null) {
                    TimerNotification = object :
                        NotificationUtils(context, TIMER_STATUS_NOTIFICATION_ID) {
                        override fun setBuilder() {
                            builder.setNotificationSilent()
                                .setOnlyAlertOnce(true)
                                .setOngoing(true)
                                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                                .addAction(com.example.motionmotivation.R.attr.reset_button_src, actionTitle, resetAction)
                        }
                    }
                }
                TimerNotification!!.updateNotification(contentText)
            }
        }
    }
}