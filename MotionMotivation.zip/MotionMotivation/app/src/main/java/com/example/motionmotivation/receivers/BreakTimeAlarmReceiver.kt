package com.example.motionmotivation.receivers

import android.R
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.motionmotivation.utils.NotificationUtils


class BreakTimeAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val contentText: String = context.resources.getString(com.example.motionmotivation.R.string.break_time_finished)
        val actionTitle: String = context.getString(com.example.motionmotivation.R.string.start)
        val notification: NotificationUtils = object :
            NotificationUtils(context, BREAK_TIME_FINISHED_NOTIFICATION_ID) {
            override fun setBuilder() {
                builder.setContentText(contentText)
                    .addAction(com.example.motionmotivation.R.attr.start_button_src, actionTitle, startAction)
            }
        }
        notification.showNotification()
    }
}