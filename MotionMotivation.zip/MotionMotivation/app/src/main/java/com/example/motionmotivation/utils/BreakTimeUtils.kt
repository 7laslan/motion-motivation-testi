package com.example.motionmotivation.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.preference.PreferenceManager
import com.example.motionmotivation.receivers.BreakTimeAlarmReceiver
import java.util.*


class BreakTimeUtils(context: Context) {
    private val breakTimeInMins: Int
    var context: Context = context

    fun start() {
        if (breakTimeInMins != 0) {
            val time: Calendar = Calendar.getInstance()
            time.timeInMillis = System.currentTimeMillis()
            time.add(Calendar.MINUTE, breakTimeInMins)
            val intent = Intent(context, BreakTimeAlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, 0)
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager[AlarmManager.RTC_WAKEUP, time.timeInMillis] = pendingIntent
        }
    }

    init {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        breakTimeInMins = sharedPreferences.getInt("breaktime", 0)
    }
}