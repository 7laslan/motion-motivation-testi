package com.example.motionmotivation.utils

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.motionmotivation.MainActivity
import com.example.motionmotivation.SittingTimerService
import com.example.motionmotivation.SittingTimerService.Companion.MM_BREAK_TIME_ACTION_START
import com.example.motionmotivation.SittingTimerService.Companion.MM_TIMER_ACTION_RESET
import com.example.motionmotivation.SittingTimerService.Companion.MM_TIMER_ACTION_START


abstract class NotificationUtils(context: Context, private val NOTIFICATION_ID: Int) {
    private val notificationManager: NotificationManagerCompat = NotificationManagerCompat.from(context)
    protected var builder: NotificationCompat.Builder
    private val context: Context = context

    protected abstract fun setBuilder()

    fun showNotification() {
        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    fun updateNotification(currentTime: String?) {
        builder.setContentText(currentTime)
        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    private val mainActivityPendingIntent: PendingIntent
        get() {
            val activityIntent = Intent(context, MainActivity::class.java)
            val taskStackBuilder = TaskStackBuilder.create(context)
            taskStackBuilder.addNextIntent(activityIntent)
            return taskStackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
        }

    protected val resetAction: PendingIntent
        get() {
            val resetActionIntent =
                Intent(context, SittingTimerService::class.java).setAction(MM_TIMER_ACTION_RESET)
            return PendingIntent.getService(context, 0, resetActionIntent, 0)
        }

    protected val startAction: PendingIntent
         get() {
            val startActionIntent =
                Intent(context, SittingTimerService::class.java).setAction(MM_TIMER_ACTION_START)
            return PendingIntent.getService(context, 0, startActionIntent, 0)
        }

    protected val breakAction: PendingIntent
         get() {
            val breakActionIntent = Intent(context, SittingTimerService::class.java).setAction(
                MM_BREAK_TIME_ACTION_START
            )
            return PendingIntent.getService(context, 0, breakActionIntent, 0)
        }

    private fun createNotificationChannel(context: Context, channelId: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name: CharSequence = context.getString(com.example.motionmotivation.R.string.notification_channel_name)
            val description = context.getString(com.example.motionmotivation.R.string.notification_channel_description)
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val soundURI =
                Uri.parse("android.resource://" + context.packageName + "/" + com.example.motionmotivation.R.raw.sound1)
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val notificationChannel = NotificationChannel(channelId, name, importance)
            notificationChannel.description = description
            notificationChannel.setSound(soundURI, audioAttributes)
            val notificationManager = NotificationManagerCompat.from(context)
            notificationManager.createNotificationChannel(notificationChannel)
            notificationManager.deleteNotificationChannel(channelId)
            notificationManager.createNotificationChannel(notificationChannel)
        }
    }

    companion object {
        const val TIMER_STATUS_NOTIFICATION_ID = 0
        const val TIMER_FINISHED_NOTIFICATION_ID = 1
        const val BREAK_TIME_FINISHED_NOTIFICATION_ID = 2
    }

    init {
        val timerChannelId = "KillerChairNC"
        createNotificationChannel(context, timerChannelId)
        val soundURI = Uri.parse("android.resource://" + context.packageName + "/" + com.example.motionmotivation.R.raw.sound0)
        builder = NotificationCompat.Builder(context, timerChannelId)
            .setSmallIcon(com.example.motionmotivation.R.drawable.ic_stat_name)
            .setContentText("")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(mainActivityPendingIntent)
            .setDefaults(Notification.DEFAULT_LIGHTS)
            .setSound(soundURI, AudioManager.STREAM_NOTIFICATION)
        setBuilder()
    }
}