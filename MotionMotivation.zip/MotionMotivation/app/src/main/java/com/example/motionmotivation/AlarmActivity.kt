package com.example.motionmotivation

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.example.motionmotivation.utils.AlarmUtils
import com.example.motionmotivation.utils.ThemeUtils


class AlarmActivity : AppCompatActivity() {

    private var alarm: AlarmUtils? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeUtils.checkTheme(this)
        setContentView(R.layout.activity_alarm)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager: KeyguardManager? =
                getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager?.requestDismissKeyguard(this, null)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
            )
        }
        val breakButton = findViewById<Button>(R.id.alarmBreak)
        val stopButton = findViewById<ImageButton>(R.id.alarmStop)
        alarm = AlarmUtils()
        alarm!!.start()
        stopButton.setOnClickListener {
            alarm!!.stop()
            onBackPressed()
        }
        breakButton.setOnClickListener {
            alarm!!.stop()
            val intent = Intent(applicationContext, SittingTimerService::class.java)
            intent.action = SittingTimerService.MM_BREAK_TIME_ACTION_START
            startService(intent)
            onBackPressed()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP) || (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            alarm!!.stop()
        }
        return true
    }
}