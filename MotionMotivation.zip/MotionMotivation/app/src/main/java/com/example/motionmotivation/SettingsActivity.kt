package com.example.motionmotivation

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.motionmotivation.utils.ThemeUtils


class SettingsActivity : AppCompatActivity(), SettingsFragment.OnThemeChangeListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeUtils.checkTheme(this)
        setContentView(R.layout.settings_activity)
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.settings, SettingsFragment())
            .commit()
        val returnButton = findViewById<Button>(R.id.sittingsReturn)
        returnButton.setOnClickListener { onBackPressed() }
    }

    override fun onThemeChange() {
        recreate()
    }
}


