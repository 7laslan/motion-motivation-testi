package com.example.motionmotivation

import android.content.Context
import android.content.SharedPreferences
import android.content.SharedPreferences.OnSharedPreferenceChangeListener
import android.os.Bundle
import android.preference.PreferenceManager
import androidx.preference.PreferenceFragmentCompat
import com.example.motionmotivation.utils.ThemeUtils

class SettingsFragment : PreferenceFragmentCompat(),
    OnSharedPreferenceChangeListener {
    private var onThemeChangeListener: OnThemeChangeListener? = null
    private var sharedPreferences: SharedPreferences? = null

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(
            R.xml.root_preferences,
            rootKey
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (context != null) {
            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        }
    }

    override fun onResume() {
        super.onResume()
        sharedPreferences!!.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onPause() {
        sharedPreferences!!.unregisterOnSharedPreferenceChangeListener(this)
        super.onPause()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        onThemeChangeListener = context as OnThemeChangeListener
    }

    interface OnThemeChangeListener {
        fun onThemeChange()
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, s: String) {
        if (s == ThemeUtils.ThemeKey) {
            onThemeChangeListener!!.onThemeChange()
        }
    }
}