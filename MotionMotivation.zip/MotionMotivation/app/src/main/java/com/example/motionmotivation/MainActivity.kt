package com.example.motionmotivation

import android.content.*
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.annotation.Nullable
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.NotificationManagerCompat
import com.example.motionmotivation.utils.CircularProgressBar
import com.example.motionmotivation.utils.NotificationUtils
import com.example.motionmotivation.utils.SittingTimerUtils.Companion.MM_TIMER_ACTION_Time_CHANGED
import com.example.motionmotivation.utils.SittingTimerUtils.Companion.formatTimeText
import com.example.motionmotivation.utils.ThemeUtils


class MainActivity : AppCompatActivity() {
    val THEME_REQUEST_CODE = 1
    private var circularProgressBar: CircularProgressBar? = null
    private var timerTimeTextView: TextView? = null
    private var stopActionButton: ImageButton? = null
    private var context: Context? = null
    private var timerUIReceiver: TimerUIReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtils.checkTheme(this)
        super.onCreate(savedInstanceState)
        context = this
        val timerLayout = findViewById<ConstraintLayout>(R.id.timer_Layout)
        timerTimeTextView = timerLayout.findViewById(R.id.timer_time)
        findViewById<TextView>(R.id.quote)
        //circularProgressBar = findViewById<TextView>(com.example.motionmotivation.R.id.custom_progressBar)
        stopActionButton = findViewById(R.id.action_stoptimer)
        val settingsActivityButton = findViewById<ImageButton>(R.id.settings_activity_button)
        NotificationManagerCompat.from(context as MainActivity).cancel(0)
        timerTimeTextView?.text = setDefTimeTextView()
        //quoteTextView.text = pickRandomQuote()

        // Avaa asetukset kun painaa
        settingsActivityButton.setOnClickListener(object : DialogInterface.OnClickListener,
            View.OnClickListener {
            override fun onClick(p0: DialogInterface?, p1: Int) {
                val intent = Intent(context, SettingsActivity::class.java)
                startActivityForResult(intent, THEME_REQUEST_CODE)
            }
            override fun onClick(p0: View?) {
                val intent = Intent(context, SettingsActivity::class.java)
                startActivityForResult(intent, THEME_REQUEST_CODE)
            }
        })

        // Kuuntelee kun nappia painetaan -> aloittaa timerin
        timerLayout.setOnClickListener { // Paina aloittaaksesi
            val startIntent = Intent(context, SittingTimerService::class.java)
            startIntent.action = SittingTimerService.MM_BREAK_TIME_ACTION_START
            (context as MainActivity).startService(startIntent)
            stopActionButton!!.visibility = View.VISIBLE
        }

        timerLayout.setOnLongClickListener { // Paina pohjaan resetoidaksesi
            val resetIntent = Intent(context, SittingTimerService::class.java)
            resetIntent.action = SittingTimerService.MM_TIMER_ACTION_RESET
            (context as MainActivity).startService(resetIntent)
            false
        }

        // Lopettaa timerin kun painetaan nappia
        stopActionButton!!.setOnClickListener {
            val stopIntent = Intent(context, SittingTimerService::class.java)
            stopIntent.action = SittingTimerService.MM_TIMER_ACTION_STOP
            (context as MainActivity).startService(stopIntent)
            stopActionButton!!.visibility = View.INVISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        timerUIReceiver = TimerUIReceiver()
        val intentFilter = IntentFilter(MM_TIMER_ACTION_Time_CHANGED)
        intentFilter.priority = 10
        this.registerReceiver(timerUIReceiver, intentFilter)
        context?.let {
            NotificationManagerCompat.from(it)
                .cancel(NotificationUtils.TIMER_STATUS_NOTIFICATION_ID)
        }
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(timerUIReceiver)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, @Nullable data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == THEME_REQUEST_CODE) {
            recreate()
        }
    }

    /*private fun pickRandomQuote(): String {
        val quotes = resources.getStringArray(com.example.motionmotivation.R.array.quotes)
        val random = kotlin.random.defaultRandom()
        return quotes[random.nextInt(quotes.size)]
    }*/

    private fun setDefTimeTextView(): String? {
        val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context)
        val time = sharedPrefs.getInt("SittingInterval", 0)
        return context?.let { formatTimeText(time * 60000, 100, it) }
    }

    // UI päivitys
    inner class TimerUIReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != null) {
                if (intent.action == MM_TIMER_ACTION_Time_CHANGED) {
                    abortBroadcast()
                    var currentTimeText: String? = context.getString(R.string.zero_time)
                    var progressInPercent = 0
                    try {
                        currentTimeText = intent.getStringExtra("currentTimeleft")
                        progressInPercent = intent.getIntExtra("progressInPercent", 0)
                    } catch (e: Exception) {
                        Log.e("intent", "onReceive-transferTimeProgress")
                    }
                    timerTimeTextView!!.text = currentTimeText
                    circularProgressBar!!.setProgress(progressInPercent)
                    circularProgressBar!!.setColor(progressInPercent)
                }
            }
        }
    }
}