package com.example.motionmotivation

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.IBinder
import android.preference.PreferenceManager
import androidx.core.app.NotificationManagerCompat
import com.example.motionmotivation.receivers.TimerFinishedReceiver
import com.example.motionmotivation.receivers.TimerNotificationReceiver
import com.example.motionmotivation.utils.BreakTimeUtils
import com.example.motionmotivation.utils.NotificationUtils
import com.example.motionmotivation.utils.SittingTimerUtils
import com.example.motionmotivation.utils.SittingTimerUtils.Companion.MM_TIMER_ACTION_FINISHED
import com.example.motionmotivation.utils.SittingTimerUtils.Companion.MM_TIMER_ACTION_Time_CHANGED


class SittingTimerService : Service() {
    private var SittingTimer: SittingTimerUtils? = null
    private var timeNotificationReceiver: TimerNotificationReceiver? = null
    private var timerFinishedReceiver: TimerFinishedReceiver? = null
    private var sharedPrefs: SharedPreferences? = null
    var context: Context? = null

    override fun onCreate() {
        super.onCreate()
        context = this
        sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context)
        val sittingTimeInMins = sharedPrefs!!.getInt("SittingInterval", 25).toLong()
        SittingTimer = SittingTimerUtils(sittingTimeInMins * 60000, 0, 1000,
            context as SittingTimerService
        )
        timeNotificationReceiver = TimerNotificationReceiver()
        timerFinishedReceiver = TimerFinishedReceiver()
        this.registerReceiver(timeNotificationReceiver, IntentFilter(MM_TIMER_ACTION_Time_CHANGED))
        this.registerReceiver(timerFinishedReceiver, IntentFilter(MM_TIMER_ACTION_FINISHED))
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        if (intent.action != null) {
            when (intent.action) {
                MM_TIMER_ACTION_START -> if (!SittingTimer!!.isRunning) {
                    SittingTimer!!.startTimer()
                }
                MM_TIMER_ACTION_RESET -> if (!SittingTimer!!.isRunning) {
                    SittingTimer!!.resetTimer()
                }
                MM_TIMER_ACTION_STOP -> {
                    if (SittingTimer!!.isRunning) {
                        val nextIntervalInMins =
                            sharedPrefs!!.getInt("SittingInterval", 25).toLong()
                        SittingTimer!!.stopTimer(nextIntervalInMins * 60000)
                    }
                    stopSelf()
                }
                MM_BREAK_TIME_ACTION_START -> {
                    val breakTime = context?.let { BreakTimeUtils(it) }
                    context?.let {
                        NotificationManagerCompat.from(it)
                            .cancel(NotificationUtils.TIMER_FINISHED_NOTIFICATION_ID)
                    }
                    breakTime!!.start()
                }
                else -> {}
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterReceiver(timeNotificationReceiver)
        unregisterReceiver(timerFinishedReceiver)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    companion object {
        const val MM_TIMER_ACTION_START = "com.example.motionmotivation.actionstart"
        const val MM_TIMER_ACTION_STOP = "com.example.motionmotivation.actionstop"
        const val MM_TIMER_ACTION_RESET = "com.example.motionmotivation.actionreset"
        const val MM_BREAK_TIME_ACTION_START = "com.example.motionmotivation.actionstartbreak"
    }
}